1- open netbeabs
2- open project 
3 -select suduko and Open it


دعواتكم


